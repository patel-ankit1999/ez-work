#!/usr/bin/env python
# coding: utf-8

# In[1]:


import xml.etree.ElementTree as ET


# In[2]:


pip install psycopg2-binary lxml


# In[6]:


import gzip
import xml.etree.ElementTree as ET

def read_tmx_file('ar-en.tmx.gz'):
    with gzip.open('ar-en.tmx.gz', 'rb') as tmx_file:
        tree = ET.parse(tmx_file)
        root = tree.getroot()
        return root.findall(".//tuv")


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:




